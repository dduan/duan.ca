import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var avatarView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11, *) {
            self.avatarView.accessibilityIgnoresInvertColors = true
        }
    }
}
